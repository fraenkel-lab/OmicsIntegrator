.. :changelog:

History
-------

0.2.0 (2016-04-13)
---------------------
* Add a Forest integration test
* Correct nondeterministic msgsteiner behavior
* Add additional example data sets and scripts
* Switch to Creative Commons Attribution-NonCommercial 4.0 International Public License
* Rename Forest configuration file parameter n to garnetBeta
* Add Forest configuration file parameter processes
* Correct error in negative prize score calculation
* Improve Garnet output file format
* Add Forest option to exclude terminals

0.1.0 (2015-04-01)
---------------------
* First release on PyPI.
