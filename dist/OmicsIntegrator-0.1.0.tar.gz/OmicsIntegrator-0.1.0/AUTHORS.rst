=======
Credits
=======

Development Lead
----------------

* Sara Gosline <sgosline@mit.edu>
* Mandy Kedaigle <mandyjoy@mit.edu>

Contributors
------------
* Nurcan Tuncbag <ntuncbag@mit.edu>
* Anthony Soltis <asoltis@mit.edu>
* Anthony Gitter <gitter@biostat.wisc.edu>

 
